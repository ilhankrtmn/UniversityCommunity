select * from Users order by 1 desc


select * from Announcements order by 1 desc
select * from Communities order by 1 desc
select * from CommunityEvents order by 1 desc
select * from CommunityMembers order by 1 desc
select * from EventTypes order by 1 desc
select * from OutgoingMails order by 1 desc
select * from UserEmailOtps order by 1 desc
select * from Users order by 1 desc
select * from UserTypes order by 1 desc

